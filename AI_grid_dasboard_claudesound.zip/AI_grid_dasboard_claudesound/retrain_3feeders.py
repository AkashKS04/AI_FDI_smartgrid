import pandas as pd
import numpy as np
import glob
import joblib

from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix

# ================= PARAMETERS =================
WINDOW_SIZE = 15
STEP = 7
SAMPLE_INTERVAL = 0.1
# ==============================================

def extract_features(df, label):
    features = []

    V = df['Vbus'].values
    I = df['Isense'].values

    for i in range(0, len(V) - WINDOW_SIZE, STEP):
        v = V[i:i+WINDOW_SIZE]
        i_cur = I[i:i+WINDOW_SIZE]

        feat = {
            'V_mean': np.mean(v),
            'V_std': np.std(v),
            'V_min': np.min(v),
            'V_max': np.max(v),
            'V_rms': np.sqrt(np.mean(v**2)),

            'I_mean': np.mean(i_cur),
            'I_std': np.std(i_cur),
            'I_min': np.min(i_cur),
            'I_max': np.max(i_cur),
            'I_rms': np.sqrt(np.mean(i_cur**2)),

            'I_drift': np.mean(np.diff(i_cur)) / SAMPLE_INTERVAL,
            'energy': np.sum(i_cur**2) * SAMPLE_INTERVAL,

            'label': label
        }

        features.append(feat)

    return features


# ================= LOAD ALL CSV FILES =================
all_features = []

files = glob.glob("*.csv")

for file in files:
    print("Processing:", file)

    if "NORMAL" in file:
        label = "NORMAL"
    elif "OPEN" in file:
        label = "OPEN"
    elif "SHORT" in file:
        label = "SHORT"
    elif "OVERLOAD" in file:
        label = "OVERLOAD"
    else:
        continue

    df = pd.read_csv(file, header=None)
    df.columns = ['Feeder', 'time', 'Vbus', 'Isense']

    feats = extract_features(df, label)
    all_features.extend(feats)

# ================= CREATE DATAFRAME =================
data = pd.DataFrame(all_features)

print("\n📊 Label Distribution:")
print(data['label'].value_counts())

# ================= SPLIT =================
X = data.drop('label', axis=1)
y = data['label']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# ================= SCALING =================
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ================= MODEL =================
model = RandomForestClassifier(
    n_estimators=200,
    max_depth=12,
    class_weight='balanced',
    random_state=42
)

model.fit(X_train_scaled, y_train)

# ================= EVALUATION =================
y_pred = model.predict(X_test_scaled)

print("\n📈 Classification Report:")
print(classification_report(y_test, y_pred))

print("\n🧾 Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# ================= SAVE =================
joblib.dump(model, "smartgrid_fdi_model.pkl")
joblib.dump(scaler, "scaler.pkl")

print("\n✅ Model trained & saved successfully!")