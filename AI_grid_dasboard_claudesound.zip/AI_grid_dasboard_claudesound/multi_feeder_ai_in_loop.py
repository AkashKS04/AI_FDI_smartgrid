import serial
import time
import joblib
import numpy as np
import pandas as pd
from datetime import datetime
from collections import deque
import keyboard

# ===== CONFIG =====
PORT = "COM6"
BAUD = 115200
WINDOW_SIZE = 15
STABILITY_COUNT = 3
FEEDERS = ["F1", "F2", "F3"]
SAMPLE_INTERVAL = 0.1
# ==================

# Load model & scaler
model = joblib.load("smartgrid_fdi_model.pkl")
scaler = joblib.load("scaler.pkl")

# Buffers
vbuf = {f: deque(maxlen=WINDOW_SIZE) for f in FEEDERS}
ibuf = {f: deque(maxlen=WINDOW_SIZE) for f in FEEDERS}
recent_preds = {f: deque(maxlen=STABILITY_COUNT) for f in FEEDERS}
last_sent = {f: None for f in FEEDERS}
is_isolated = {f: False for f in FEEDERS}

# Serial
ser = serial.Serial(PORT, BAUD, timeout=1)
time.sleep(2)

print("🔥 AI Fault Detection Started (INA219 Mode)")
print("Press 1/2/3 → Manual reclose F1/F2/F3 | q → Quit\n")

# ===== FEATURE FUNCTION =====
def compute_features(V, I):
    V = np.array(V)
    I = np.array(I)

    feats = {
        'V_mean': np.mean(V),
        'V_std': np.std(V),
        'V_min': np.min(V),
        'V_max': np.max(V),
        'V_rms': np.sqrt(np.mean(V**2)),

        'I_mean': np.mean(I),
        'I_std': np.std(I),
        'I_min': np.min(I),
        'I_max': np.max(I),
        'I_rms': np.sqrt(np.mean(I**2)),

        'I_drift': np.mean(np.diff(I)) / SAMPLE_INTERVAL,
        'energy': np.sum(I**2) * SAMPLE_INTERVAL
    }

    return pd.DataFrame([feats])

# ===== MAIN LOOP =====
try:
    while True:

        # -------- Keyboard Manual Reclose --------
        if keyboard.is_pressed('1'):
            ser.write(b"F1_NORMAL\n")
            print("Manual Reclose → F1")
            time.sleep(0.4)

        if keyboard.is_pressed('2'):
            ser.write(b"F2_NORMAL\n")
            print("Manual Reclose → F2")
            time.sleep(0.4)

        if keyboard.is_pressed('3'):
            ser.write(b"F3_NORMAL\n")
            print("Manual Reclose → F3")
            time.sleep(0.4)

        if keyboard.is_pressed('q'):
            break

        # -------- Read Serial --------
        line = ser.readline().decode().strip()
        if not line:
            continue

        parts = line.split(',')
        if len(parts) < 4:
            continue

        feeder = parts[0]

        try:
            v = float(parts[2])
            i = float(parts[3])
        except:
            continue

        if feeder not in FEEDERS:
            continue

        vbuf[feeder].append(v)
        ibuf[feeder].append(i)

        if len(vbuf[feeder]) == WINDOW_SIZE:
            X = compute_features(vbuf[feeder], ibuf[feeder])
            X_scaled = scaler.transform(X)
            pred = model.predict(X_scaled)[0]

            now = datetime.now().strftime("%H:%M:%S")
            print(f"[{now}] {feeder} → {pred}")

            recent_preds[feeder].append(pred)

            # ===== STABLE DECISION =====
            if len(recent_preds[feeder]) == STABILITY_COUNT and len(set(recent_preds[feeder])) == 1:
                stable = recent_preds[feeder][0]

                # ---- Fault detected ----
                if stable in ["SHORT", "OPEN", "OVERLOAD"] and not is_isolated[feeder]:
                    ser.write(f"{feeder}_{stable}\n".encode())
                    print(f"⚡ {feeder} FAULT → {stable} → RELAY OFF")
                    is_isolated[feeder] = True

                # ---- Normal detected ----
                elif stable == "NORMAL":
                    if not is_isolated[feeder]:
                        # keep synced
                        ser.write(f"{feeder}_NORMAL\n".encode())

        time.sleep(0.02)

except KeyboardInterrupt:
    print("Stopped")

finally:
    ser.close()