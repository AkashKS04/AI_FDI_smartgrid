import serial
import time
import joblib
import numpy as np
import pandas as pd
from datetime import datetime
from collections import deque
import threading

from flask import Flask, render_template_string, send_from_directory
from flask_socketio import SocketIO, emit
import os

# ===== CONFIG =====
PORT = "COM6"
BAUD = 115200
WINDOW_SIZE = 15
STABILITY_COUNT = 3
FEEDERS = ["F1", "F2", "F3"]
SAMPLE_INTERVAL = 0.1
VOLTAGE_THRESHOLD = 10.0
# ==================

app = Flask(__name__)
app.config['SECRET_KEY'] = 'smartgrid2024'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# ===== SHARED STATE =====
vbuf = {f: deque(maxlen=WINDOW_SIZE) for f in FEEDERS}
ibuf = {f: deque(maxlen=WINDOW_SIZE) for f in FEEDERS}
recent_preds = {f: deque(maxlen=STABILITY_COUNT) for f in FEEDERS}
is_isolated = {f: False for f in FEEDERS}

feeder_state = {
    f: {
        "voltage": 0.0,
        "current": 0.0,
        "status": "NORMAL",
        "isolated": False,
        "last_fault": None,
        "timestamp": ""
    } for f in FEEDERS
}

log_entries = deque(maxlen=100)
ser = None

def load_models():
    model = joblib.load("smartgrid_fdi_model.pkl")
    scaler = joblib.load("scaler.pkl")
    return model, scaler

def compute_features(V, I):
    V = np.array(V)
    I = np.array(I)
    feats = {
        'V_mean': np.mean(V),
        'V_std': np.std(V),
        'V_min': np.min(V),
        'V_max': np.max(V),
        'V_rms': np.sqrt(np.mean(V**2)),
        'I_mean': np.mean(I),
        'I_std': np.std(I),
        'I_min': np.min(I),
        'I_max': np.max(I),
        'I_rms': np.sqrt(np.mean(I**2)),
        'I_drift': np.mean(np.diff(I)) / SAMPLE_INTERVAL,
        'energy': np.sum(I**2) * SAMPLE_INTERVAL
    }
    return pd.DataFrame([feats]), feats

def add_log(msg, level="info"):
    ts = datetime.now().strftime("%H:%M:%S")
    entry = {"time": ts, "msg": msg, "level": level}
    log_entries.appendleft(entry)
    socketio.emit('log', entry)

def push_state():
    data = {}
    for f in FEEDERS:
        data[f] = dict(feeder_state[f])
    socketio.emit('state_update', data)

def serial_loop(model, scaler):
    global ser
    try:
        ser = serial.Serial(PORT, BAUD, timeout=1)
        time.sleep(2)
        add_log(f"Serial connected on {PORT}", "info")
    except Exception as e:
        add_log(f"Serial connection failed: {e}", "error")
        return

    while True:
        try:
            line = ser.readline().decode().strip()
            if not line:
                continue

            parts = line.split(',')
            if len(parts) < 4:
                continue

            feeder = parts[0]
            try:
                v = float(parts[2])
                i = float(parts[3])
            except:
                continue

            if feeder not in FEEDERS:
                continue

            vbuf[feeder].append(v)
            ibuf[feeder].append(i)

            now = datetime.now().strftime("%H:%M:%S")
            feeder_state[feeder]["voltage"] = round(v, 3)
            feeder_state[feeder]["current"] = round(i, 4)
            feeder_state[feeder]["timestamp"] = now

            # Prediction
            if len(vbuf[feeder]) == WINDOW_SIZE:
                X, feats = compute_features(vbuf[feeder], ibuf[feeder])
                X_scaled = scaler.transform(X)
                pred = model.predict(X_scaled)[0]
                recent_preds[feeder].append(pred)

                if pred != "NORMAL":
                    feeder_state[feeder]["status"] = pred

            # Decision block
            stable_preds = {}
            for f in FEEDERS:
                if len(recent_preds[f]) == STABILITY_COUNT and len(set(recent_preds[f])) == 1:
                    stable_preds[f] = recent_preds[f][0]

            # PRIORITY 1: SHORT
            short_feeders = [f for f in stable_preds if stable_preds[f] == "SHORT"]
            if short_feeders:
                max_f = max(short_feeders, key=lambda f: np.mean(ibuf[f]))
                if not is_isolated[max_f]:
                    ser.write(f"{max_f}_SHORT\r\n".encode())
                    is_isolated[max_f] = True
                    feeder_state[max_f]["isolated"] = True
                    feeder_state[max_f]["status"] = "SHORT"
                    feeder_state[max_f]["last_fault"] = "SHORT"
                    add_log(f"SHORT on {max_f} — relay opened", "critical")
                    push_state()
                continue

            # PRIORITY 2: OVERLOAD
            for f in stable_preds:
                if stable_preds[f] == "OVERLOAD" and not is_isolated[f]:
                    ser.write(f"{f}_OVERLOAD\r\n".encode())
                    is_isolated[f] = True
                    feeder_state[f]["isolated"] = True
                    feeder_state[f]["status"] = "OVERLOAD"
                    feeder_state[f]["last_fault"] = "OVERLOAD"
                    add_log(f"OVERLOAD on {f} — relay opened", "warning")

            # PRIORITY 3: OPEN
            for f in stable_preds:
                if stable_preds[f] == "OPEN":
                    avg_v = np.mean(vbuf[f])
                    if avg_v > VOLTAGE_THRESHOLD:
                        if not is_isolated[f]:
                            ser.write(f"{f}_OPEN\r\n".encode())
                            is_isolated[f] = True
                            feeder_state[f]["isolated"] = True
                            feeder_state[f]["status"] = "OPEN"
                            feeder_state[f]["last_fault"] = "OPEN"
                            add_log(f"OPEN on {f} — relay opened", "warning")
                    else:
                        add_log(f"False OPEN ignored on {f} (voltage dip)", "info")

            push_state()
            time.sleep(0.02)

        except Exception as e:
            add_log(f"Serial read error: {e}", "error")
            time.sleep(1)


# ===== SOCKET EVENTS =====
@socketio.on('connect')
def on_connect():
    emit('state_update', {f: dict(feeder_state[f]) for f in FEEDERS})
    emit('log_history', list(log_entries))

@socketio.on('reclose')
def on_reclose(data):
    feeder = data.get('feeder')
    if feeder not in FEEDERS:
        return
    if ser and ser.is_open:
        ser.write(f"{feeder}_NORMAL\r\n".encode())
    is_isolated[feeder] = False
    feeder_state[feeder]["isolated"] = False
    feeder_state[feeder]["status"] = "NORMAL"
    feeder_state[feeder]["last_fault"] = None
    recent_preds[feeder].clear()
    add_log(f"{feeder} manually reclosed via dashboard", "info")
    push_state()

@socketio.on('force_isolate')
def on_force_isolate(data):
    feeder = data.get('feeder')
    if feeder not in FEEDERS:
        return
    if ser and ser.is_open:
        ser.write(f"{feeder}_MANUAL_OPEN\r\n".encode())
    is_isolated[feeder] = True
    feeder_state[feeder]["isolated"] = True
    feeder_state[feeder]["status"] = "MANUAL"
    feeder_state[feeder]["last_fault"] = "MANUAL"
    add_log(f"{feeder} manually isolated via dashboard", "warning")
    push_state()

# ===== SERVE DASHBOARD =====
DASHBOARD_HTML = open(os.path.join(os.path.dirname(__file__), "dashboard.html"), encoding="utf-8").read()

@app.route('/')
def index():
    return DASHBOARD_HTML

if __name__ == '__main__':
    print("Loading AI models...")
    model, scaler = load_models()
    print("Models loaded.")

    t = threading.Thread(target=serial_loop, args=(model, scaler), daemon=True)
    t.start()

    print("Dashboard running at http://localhost:5000")
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)
