#include <Wire.h>
#include <Adafruit_INA219.h>

// ================= INA219 (3 feeders with unique addresses) =================
Adafruit_INA219 inaF1(0x40);
Adafruit_INA219 inaF2(0x41);
Adafruit_INA219 inaF3(0x44);

// ================= RELAY PINS =================
const int relayF1 = 25;
const int relayF2 = 26;
const int relayF3 = 27;

// Relay logic (change if needed)
const int RELAY_ON  = HIGH;
const int RELAY_OFF = LOW;

unsigned long t0 = 0;

// ================= SETUP =================
void setup() {
  Serial.begin(115200);
  delay(1000);

  Wire.begin(21, 22);  // SDA, SCL

  // Initialize INA219
  if (!inaF1.begin()) Serial.println("F1 INA219 not found");
  if (!inaF2.begin()) Serial.println("F2 INA219 not found");
  if (!inaF3.begin()) Serial.println("F3 INA219 not found");

  // Relay setup
  pinMode(relayF1, OUTPUT);
  pinMode(relayF2, OUTPUT);
  pinMode(relayF3, OUTPUT);

  // Default ON
  digitalWrite(relayF1, RELAY_ON);
  digitalWrite(relayF2, RELAY_ON);
  digitalWrite(relayF3, RELAY_ON);

  Serial.println("System Ready: F#,time_ms,Vbus_V,Isense_A");

  t0 = millis();
}

// ================= RELAY CONTROL =================
void controlRelay(String cmd) {
  cmd.trim();

  if (cmd.startsWith("F1_")) {
    if (cmd == "F1_NORMAL") digitalWrite(relayF1, RELAY_ON);
    else digitalWrite(relayF1, RELAY_OFF);
  }
  else if (cmd.startsWith("F2_")) {
    if (cmd == "F2_NORMAL") digitalWrite(relayF2, RELAY_ON);
    else digitalWrite(relayF2, RELAY_OFF);
  }
  else if (cmd.startsWith("F3_")) {
    if (cmd == "F3_NORMAL") digitalWrite(relayF3, RELAY_ON);
    else digitalWrite(relayF3, RELAY_OFF);
  }
}

// ================= LOOP =================
void loop() {
  unsigned long t = millis() - t0;

  // ===== F1 =====
  float v1 = inaF1.getBusVoltage_V();
  float i1 = inaF1.getCurrent_mA() / 1000.0;
  Serial.print("F1,"); Serial.print(t);
  Serial.print(","); Serial.print(v1, 3);
  Serial.print(","); Serial.println(i1, 3);

  // ===== F2 =====
  float v2 = inaF2.getBusVoltage_V();
  float i2 = inaF2.getCurrent_mA() / 1000.0;
  Serial.print("F2,"); Serial.print(t);
  Serial.print(","); Serial.print(v2, 3);
  Serial.print(","); Serial.println(i2, 3);

  // ===== F3 =====
  float v3 = inaF3.getBusVoltage_V();
  float i3 = inaF3.getCurrent_mA() / 1000.0;
  Serial.print("F3,"); Serial.print(t);
  Serial.print(","); Serial.print(v3, 3);
  Serial.print(","); Serial.println(i3, 3);

  // ===== Read commands from Python =====
  while (Serial.available()) {
    String cmd = Serial.readStringUntil('\n');
    controlRelay(cmd);
  }

  delay(100);  // 10 Hz sampling
}