import serial
import time
import joblib
import numpy as np
import pandas as pd
from datetime import datetime
from collections import deque
import keyboard

# ===== CONFIG =====
PORT = "COM6"
BAUD = 115200
WINDOW_SIZE = 15
STABILITY_COUNT = 3
FEEDERS = ["F1", "F2", "F3"]
SAMPLE_INTERVAL = 0.1
VOLTAGE_THRESHOLD = 10.0  # critical for OPEN validation
# ==================

model = joblib.load("smartgrid_fdi_model.pkl")
scaler = joblib.load("scaler.pkl")

vbuf = {f: deque(maxlen=WINDOW_SIZE) for f in FEEDERS}
ibuf = {f: deque(maxlen=WINDOW_SIZE) for f in FEEDERS}
recent_preds = {f: deque(maxlen=STABILITY_COUNT) for f in FEEDERS}

is_isolated = {f: False for f in FEEDERS}

ser = serial.Serial(PORT, BAUD, timeout=1)
time.sleep(2)

print("🔥 ROBUST AI FAULT DETECTION STARTED")

def compute_features(V, I):
    V = np.array(V)
    I = np.array(I)

    feats = {
        'V_mean': np.mean(V),
        'V_std': np.std(V),
        'V_min': np.min(V),
        'V_max': np.max(V),
        'V_rms': np.sqrt(np.mean(V**2)),

        'I_mean': np.mean(I),
        'I_std': np.std(I),
        'I_min': np.min(I),
        'I_max': np.max(I),
        'I_rms': np.sqrt(np.mean(I**2)),

        'I_drift': np.mean(np.diff(I)) / SAMPLE_INTERVAL,
        'energy': np.sum(I**2) * SAMPLE_INTERVAL
    }

    return pd.DataFrame([feats]), feats

try:
    while True:

        # -------- Manual Reclose --------
        if keyboard.is_pressed('1'):
            ser.write(b"F1_NORMAL\r\n")
            is_isolated["F1"] = False
            print("Manual Reclose F1")
            time.sleep(0.4)

        if keyboard.is_pressed('2'):
            ser.write(b"F2_NORMAL\r\n")
            is_isolated["F2"] = False
            print("Manual Reclose F2")
            time.sleep(0.4)

        if keyboard.is_pressed('3'):
            ser.write(b"F3_NORMAL\r\n")
            is_isolated["F3"] = False
            print("Manual Reclose F3")
            time.sleep(0.4)

        # -------- Read Data --------
        line = ser.readline().decode().strip()
        if not line:
            continue

        parts = line.split(',')
        if len(parts) < 4:
            continue

        feeder = parts[0]

        try:
            v = float(parts[2])
            i = float(parts[3])
        except:
            continue

        if feeder not in FEEDERS:
            continue

        vbuf[feeder].append(v)
        ibuf[feeder].append(i)

        # -------- Prediction --------
        if len(vbuf[feeder]) == WINDOW_SIZE:
            X, feats = compute_features(vbuf[feeder], ibuf[feeder])
            X_scaled = scaler.transform(X)
            pred = model.predict(X_scaled)[0]

            recent_preds[feeder].append(pred)

            now = datetime.now().strftime("%H:%M:%S")
            print(f"[{now}] {feeder} → {pred} | V={feats['V_mean']:.2f}V | I={feats['I_mean']:.3f}A")

        # -------- DECISION BLOCK --------
        stable_preds = {}

        for f in FEEDERS:
            if len(recent_preds[f]) == STABILITY_COUNT and len(set(recent_preds[f])) == 1:
                stable_preds[f] = recent_preds[f][0]

        # ===== PRIORITY 1: SHORT =====
        short_feeders = [f for f in stable_preds if stable_preds[f] == "SHORT"]

        if short_feeders:
            # isolate ONLY feeder with highest current
            max_f = max(short_feeders, key=lambda f: np.mean(ibuf[f]))

            if not is_isolated[max_f]:
                ser.write(f"{max_f}_SHORT\r\n".encode())
                is_isolated[max_f] = True
                print(f"🚨 SHORT detected → {max_f} isolated")

            continue  # ignore all other faults

        # ===== PRIORITY 2: OVERLOAD =====
        for f in stable_preds:
            if stable_preds[f] == "OVERLOAD" and not is_isolated[f]:
                ser.write(f"{f}_OVERLOAD\r\n".encode())
                is_isolated[f] = True
                print(f"⚠️ OVERLOAD → {f} isolated")

        # ===== PRIORITY 3: OPEN (with voltage check) =====
        for f in stable_preds:
            if stable_preds[f] == "OPEN":
                avg_v = np.mean(vbuf[f])

                if avg_v > VOLTAGE_THRESHOLD:  # valid open
                    if not is_isolated[f]:
                        ser.write(f"{f}_OPEN\r\n".encode())
                        is_isolated[f] = True
                        print(f"🔌 OPEN → {f} isolated")
                else:
                    print(f"⚠️ Ignored false OPEN on {f} (voltage dip)")

        time.sleep(0.02)

except KeyboardInterrupt:
    print("Stopped")

finally:
    ser.close()