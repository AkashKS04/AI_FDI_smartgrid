import serial
import time
import csv
import sys
import threading

PORT = "COM6"   # change if needed
BAUD = 115200

ser = serial.Serial(PORT, BAUD, timeout=1)
time.sleep(2)

print("Connected to ESP32")

# ================= STATE =================
current_feeder = "F1"
current_label = "NORMAL"
running = True

# create file
filename = f"{current_feeder}_{current_label}.csv"
file = open(filename, 'w', newline='')
writer = csv.writer(file)

print("\nControls:")
print("1/2/3 → Select Feeder (F1/F2/F3)")
print("n → NORMAL | o → OPEN | s → SHORT | l → OVERLOAD")
print("q → Quit\n")

# ================= KEY INPUT THREAD =================
def input_thread():
    global current_label, current_feeder, file, writer, filename, running

    while running:
        key = sys.stdin.read(1)

        if key == '1':
            current_feeder = "F1"
            print("\nSwitched to F1")

        elif key == '2':
            current_feeder = "F2"
            print("\nSwitched to F2")

        elif key == '3':
            current_feeder = "F3"
            print("\nSwitched to F3")

        elif key == 'n':
            current_label = "NORMAL"
        elif key == 'o':
            current_label = "OPEN"
        elif key == 's':
            current_label = "SHORT"
        elif key == 'l':
            current_label = "OVERLOAD"
        elif key == 'q':
            running = False
            break
        else:
            continue

        # close old file and open new
        file.close()
        filename = f"{current_feeder}_{current_label}.csv"
        file = open(filename, 'a', newline='')
        writer = csv.writer(file)

        print(f"Recording → {filename}")

threading.Thread(target=input_thread, daemon=True).start()

# ================= MAIN LOOP =================
try:
    while running:
        line = ser.readline().decode('utf-8', errors='ignore').strip()
        if not line:
            continue

        parts = line.split(',')
        if len(parts) < 4:
            continue

        feeder = parts[0]

        # only log selected feeder
        if feeder != current_feeder:
            continue

        try:
            t = float(parts[1])
            v = float(parts[2])
            i = float(parts[3])
        except:
            continue

        writer.writerow([feeder, t, v, i])
        print(f"{feeder} | V={v:.2f}V | I={i:.2f}A | {current_label}")

except KeyboardInterrupt:
    print("\nStopped")

finally:
    file.close()
    ser.close()